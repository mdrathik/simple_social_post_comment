

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
 <div class="container">
	<div class="page-lock">
       <!--  <div class="page-logo">
    		<a class="brand" href="index.html">
    		<img src="http://keenthemes.com/preview/metronic/theme/assets/admin/layout/img/logo-big.png" alt="logo"/>
    		</a>
    	</div> -->
    	<div class="page-body">
    		<div class="lock-head">
    			Singapore
    		</div>
    		<div class="lock-body">
    			<!-- <div class="pull-left lock-avatar-block">
    				<img src="http://keenthemes.com/preview/metronic/theme/assets/admin/pages/media/profile/photo3.jpg" class="lock-avatar">
    			</div> -->
    			<form class="lock-form pull-left"  action = "checklogin.php" method = "post">
    				<h4>Login into Your Admin Panel</h4>
    				<div class="form-group">
    					<input class="form-control placeholder-no-fix" type="text" autocomplete="off" placeholder="Password" name="username"/>
    				</div>
    				<div class="form-group">
    					<input class="form-control placeholder-no-fix" type="password" autocomplete="off" placeholder="Password" name="password"/>
    				</div>
    				<div class="form-actions">
    					<button  type = "submit" 
               name = "login" value="login" class="btn btn-success uppercase">Login</button>
    				</div>
    			</form>
    		</div>
    		<div class="lock-bottom">
    		<p style="color: white;">Carefully Enter Username and Pass</p>
    		</div>
    	</div>
    </div>
</div>

<br>
<br>
<center>
<strong>@Socail Site</strong>
</center>
</body>
</html>